#!/bin/bash

sudo apt-get install build-essential curl tar pkg-config

./build.sh
